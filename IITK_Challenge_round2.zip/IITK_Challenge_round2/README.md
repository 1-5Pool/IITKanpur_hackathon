1) Install anaconda
2) Use command : conda create --name ddos --file requirements.txt
3) Use command : conda activate ddos
4) Run the program : python ddosdetect.py <TEST_PCAP_FILE>
5) Output : File called results.csv